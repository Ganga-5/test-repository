import logo from './logo.svg';
import './App.css';
// import Login from './Components/Login/login';
import LoginForm from './LoginForm';
import Home from './Components/Home'
import {Routes, Route } from 'react-router-dom'
import Navbar from './Components/Navbar';
import NavbarActiveLink from './Components/NavbarActiveLink';
import SignIn from './Components/Login/SignIn';
import SignUp from './Components/Login/SignUp';

function App() {
  return (
    <>
      <NavbarActiveLink />
      <Routes>
        <Route path='/' element={<Home />} />
        <Route path='Login' element={<LoginForm />} />
        <Route path='SignIn' element={<SignIn />} />
        <Route path='SignUp' element={<SignUp />} />
      </Routes>
    </>
  );
}

export default App;
