
import {Link} from 'react-router-dom'

function Navbar(){
    return(
        <nav>
            <Link to='/'>Home</Link>
            <Link to='Login'>LoginForm</Link>
        </nav>
    )
}
/* This is also we can use intead of <Link>
 <a href='/'>Home</a>
<a href='/Login'>LoginForm</a> */
export default Navbar;