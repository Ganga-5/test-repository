import React from "react";
import '../../LoginForm.css'
import 'bootstrap/dist/css/bootstrap.min.css'
import { useState } from "react";

function SignUp(){

    const [action, setAction] = useState("Sign In")

    return(
        <div className="wrapper bg-dark d-flex align-items-center justify-content-center w-100">
            <div className="login">
                <h2 className="mb-3">{action}</h2>
                <form className="needs-validation">

                    {action === "Sign In" ? <div></div> : 
                        <div className='form-group was-validated mb-2'>
                            <label htmlFor="text">Username</label>
                            <input type="text" className="form-control" required></input>
                            <div className="invalid-feedback">
                                Please Enter your name
                            </div>
                        </div>
                    }

                    <div className='form-group was-validated mb-2'>
                        <label htmlFor="email">Email Address</label>
                        <input type="email" className="form-control" required></input>
                        <div className="invalid-feedback">
                            Please Enter your email
                        </div>
                    </div>
                    
                    <div className="form-group was-validated mb-2">
                        <label htmlFor="password">Password</label>
                        <input type="password" className="form-control" required></input>
                        <div className="invalid-feedback">
                            Please Enter your password
                        </div>
                    </div>
                    <div className="form-group form-check mb-2">
                        <input type="checkbox" className="form-check-input"></input>
                        <label htmlFor="checkbox" className="form-check-label">Remember me!</label>
                    </div>
                    
                    <button type="submit" className={action==="Sign Up" ? 
                                    "btn btn-secondary block w-100 mt-2 log-in" : 
                                    "submit btn btn-success block w-100 mt-2 log-in"}
                                    onClick={()=>{setAction("Sign In")}}
                                    >SIGN IN</button>
                    
                    <button type="submit" className={action==="Sign In" ? 
                                    "btn btn-secondary block w-100 mt-2 log-in" : 
                                    "submit btn btn-success block w-100 mt-2 log-in"}
                                    onClick={()=>{setAction("Sign Up")}}
                                    >SIGN UP</button>   
                </form>
            </div>
        </div>
    )
    
}

export default SignUp;