import './login.css'
import User_icon from './LoginAssets/User-name-icon.png';
import Email_icon from './LoginAssets/Email-icon.png';
import Password_icon from './LoginAssets/Password-icon.png';

const Login = () => {
    return(
        <div className='container container-fluid'> 
            <div className='text-center'>
                <img src='' alt='Logo'></img>
                <div className='text'>Sign Up</div>
                
            </div>
            <div className='inputs row d-inline-flex p-4 '>
                <div className='input'>
                    <img src={User_icon} className='icon-size' alt='Username'></img>
                    <input type='text' placeholder='Username'></input>
                </div>

                <div className='input'>
                    <img src={Email_icon} className='icon-size' alt='email'></img>
                    <input type='email' placeholder='Email Id'></input>
                </div>

                <div className='input'>
                    <img src={Password_icon} className='icon-size' alt='password'></img>
                    <input type='password' placeholder='Password'></input>
                </div>
            </div>
            <div className='forgot-password'>Lost Password? 
                <span>Click Here!</span>
            </div>
            <div className='d-grid gap-2 d-md-block'>
                <button type='submit' className='btn btn-primary'>Login</button>
                <button type='submit' className='btn btn-primary'>Sign Up</button>
            </div>
        </div>

    )
}



// function Login(){
// return(
//     <div>
//         <form className='form'>
//             <h3>Login</h3>
//             <div>
//                 <div className="Username">
//                     <label>User Name</label>
//                     <input type="text" placeholder="User Name"></input>
//                 </div>

//                 <div className="Email">
//                     <label>Email</label>
//                     <input type="text" placeholder="Email Id"></input>
//                 </div>

//                 <div className="Password">
//                     <label>Password</label>
//                     <input type="password" placeholder="Password"></input>
//                 </div>
//                 <span>Forgot Password</span>
//                 <button type="Submit">Login</button>
//                 <span>Sign up</span>
                
//             </div>
//         </form>
//     </div>
// )
// }

export default Login;