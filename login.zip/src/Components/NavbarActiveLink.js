import { findRenderedComponentWithType } from "react-dom/test-utils";
import { NavLink } from "react-router-dom";

function NavbarActiveLink(){
    const navLinkStyles = ({isActive}) => {
        return {
            fontWeight: isActive ? 'bold' : 'normal',
            textDecoration: isActive ? 'none' : 'underline',
        }
    }
    return(
        <nav>
            <NavLink style={navLinkStyles} to='/'>Home</NavLink>
            <NavLink style={navLinkStyles} to='/Login'>LoginForm</NavLink>
            <NavLink style={navLinkStyles} to='SignUp'>SignUp</NavLink>
        </nav>
    )
}

export default NavbarActiveLink;